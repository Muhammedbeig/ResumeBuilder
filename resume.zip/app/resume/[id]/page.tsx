import { ResumeEditorPage } from "@/components/pages/ResumeEditor";

export default async function ResumeEditor() {
  return <ResumeEditorPage />;
}
