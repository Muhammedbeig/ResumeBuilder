import { TemplatesCatalogPage } from "@/components/pages/TemplatesCatalogPage";

export default function TemplatesPage() {
  return <TemplatesCatalogPage />;
}
