import { CVEditorPage } from "@/components/pages/CVEditorPage";

export default function Page() {
  return <CVEditorPage />;
}
