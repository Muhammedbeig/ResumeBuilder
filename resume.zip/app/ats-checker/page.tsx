import { ATSCheckerPage } from "@/components/pages/ATSCheckerPage";

export default function Page() {
  return <ATSCheckerPage />;
}
