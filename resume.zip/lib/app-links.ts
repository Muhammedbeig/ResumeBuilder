export const APP_DOWNLOAD_URL =
  "https://play.google.com/store/apps/details?id=com.resume.builder.cv.maker.resumemaker.pdf";
