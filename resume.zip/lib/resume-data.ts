import type { ResumeData, SectionConfig } from "@/types";

export const defaultSectionOrder: SectionConfig[] = [
  { id: 'basics', type: 'basics', title: 'Personal Info', isVisible: true, order: 0 },
  { id: 'summary', type: 'summary', title: 'Professional Summary', isVisible: true, order: 1 },
  { id: 'experience', type: 'experience', title: 'Experience', isVisible: true, order: 2 },
  { id: 'education', type: 'education', title: 'Education', isVisible: true, order: 3 },
  { id: 'skills', type: 'skills', title: 'Skills', isVisible: true, order: 4 },
  { id: 'projects', type: 'projects', title: 'Projects', isVisible: true, order: 5 },
  { id: 'certifications', type: 'certifications', title: 'Certifications', isVisible: true, order: 6 },
];

export const emptyResumeData: ResumeData = {
  basics: {
    name: "",
    title: "",
    location: "",
    email: "",
    phone: "",
    summary: "",
  },
  experiences: [],
  education: [],
  skills: [],
  projects: [],
  certifications: [],
  languages: [],
  structure: defaultSectionOrder,
  metadata: {},
};

export function normalizeResumeData(data?: Partial<ResumeData> | null): ResumeData {
  if (!data) return { ...emptyResumeData };

  const generateId = (prefix: string) => `${prefix}-${Math.random().toString(36).substring(2, 11)}`;

  return {
    basics: { ...emptyResumeData.basics, ...(data.basics || {}) },
    experiences: (data.experiences || []).map((item) => ({
      ...item,
      id: (item as any).id || generateId("exp"),
    })),
    education: (data.education || []).map((item) => ({
      ...item,
      id: (item as any).id || generateId("edu"),
    })),
    skills: (data.skills || []).map((item) => ({
      ...item,
      id: (item as any).id || generateId("skill"),
    })),
    projects: (data.projects || []).map((item) => ({
      ...item,
      id: (item as any).id || generateId("proj"),
    })),
    certifications: (data.certifications || []).map((item) => ({
      ...item,
      id: (item as any).id || generateId("cert"),
    })),
    languages: (data.languages || []).map((item) => ({
      ...item,
      id: (item as any).id || generateId("lang"),
    })),
    structure: data.structure || defaultSectionOrder,
    metadata: { ...emptyResumeData.metadata, ...(data.metadata || {}) },
  };
}
