import { NextRequest, NextResponse } from "next/server";
import { getGeminiModel } from "@/lib/gemini";
import { requirePaidAiAccess } from "@/lib/ai-access";
import { rateLimit } from "@/lib/rate-limit";
import { truncateText } from "@/lib/limits";
import { getResourceSettings } from "@/lib/resource-settings";
import { extractPdfText } from "@/lib/pdf-text";

export async function POST(req: NextRequest) {
  const access = await requirePaidAiAccess(req);
  if (access) return access;

  const resourceSettings = await getResourceSettings();

  const rateLimitResponse = rateLimit(req, {
    prefix: "ai-ats-check",
    limit: resourceSettings.rateLimits.aiHeavy,
    windowMs: resourceSettings.rateLimits.windowMs,
  });
  if (rateLimitResponse) return rateLimitResponse;

  const withTimeout = async <T>(
    promise: Promise<T>,
    timeoutMs: number,
    message: string,
  ): Promise<T> => {
    return await Promise.race([
      promise,
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error(message)), timeoutMs),
      ),
    ]);
  };

  try {
    const formData = await req.formData();
    const file = formData.get("file") as File;

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    // Extract text from PDF
    const buffer = Buffer.from(await file.arrayBuffer());
    let text = "";

    if (file.type === "application/pdf") {
      text = await withTimeout(
        extractPdfText(buffer, 1),
        45_000,
        "PDF extraction timed out",
      );
    } else {
      // Fallback for plain text
      text = buffer.toString("utf-8");
    }

    text = truncateText(text, resourceSettings.limits.aiText);

    if (!text || !text.trim()) {
      // If empty, try to see if JSON content has text
      // But for now return error
      if (!text)
        return NextResponse.json(
          { error: "Could not extract text from file (empty)" },
          { status: 400 },
        );
    }

    const model = await getGeminiModel();

    const prompt = `
      You are an expert ATS (Applicant Tracking System) scanner and professional resume reviewer. 
      Analyze the following resume text extracted from a document. 
      
      Provide a detailed ATS score and analysis in the following strict JSON format:
      {
        "score": number, // Overall score out of 100
        "summary": "string", // A brief executive summary of the resume's quality
        "breakdown": {
          "contact_info": { "score": number, "feedback": ["string"] },
          "professional_summary": { "score": number, "feedback": ["string"] },
          "experience": { "score": number, "feedback": ["string"] },
          "education": { "score": number, "feedback": ["string"] },
          "skills": { "score": number, "feedback": ["string"] }
        },
        "strengths": ["string"], // List of strong points
        "weaknesses": ["string"], // List of areas for improvement
        "missing_keywords": ["string"], // Important industry keywords that seem missing
        "formatting_issues": ["string"] // Potential formatting issues detected from the text structure (e.g. widely spaced characters, unusual symbols)
      }

      Ensure the "score" is realistic and critical. A perfect 100 should be rare.
      
      RESUME TEXT:
      ${text}
    `;

    const result = await withTimeout(
      model.generateContent(prompt),
      60_000,
      "ATS analysis timed out",
    );
    const response = await result.response;
    const textResponse = response.text();

    // Extract JSON from the response
    const jsonMatch =
      textResponse.match(/```json([\s\S]*?)```/) ||
      textResponse.match(/```([\s\S]*?)```/);
    let jsonData;
    if (jsonMatch) {
      jsonData = JSON.parse(jsonMatch[1]);
    } else {
      try {
        jsonData = JSON.parse(textResponse);
      } catch (e) {
        // Fallback if strict JSON parsing fails
        console.error("Failed to parse JSON", e);
        return NextResponse.json(
          { error: "Failed to analyze resume" },
          { status: 500 },
        );
      }
    }

    return NextResponse.json(jsonData);
  } catch (error) {
    console.error("Error in ATS check:", error);
    if (
      error instanceof Error &&
      (error.message.includes("timed out") ||
        error.message.includes("timeout"))
    ) {
      return NextResponse.json({ error: error.message }, { status: 504 });
    }
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 },
    );
  }
}
